# Panduan Deployment D'Fresto ke VPS (DigitalOcean / Vultr)

Panduan ini menjelaskan langkah-langkah untuk men-deploy aplikasi D'Fresto (Next.js + Prisma + PostgreSQL) ke Virtual Private Server (VPS) berbasis Ubuntu 22.04 / 24.04.

## Prasyarat

1.  **VPS**: Minimal 1GB RAM (Disarankan 2GB+ untuk Next.js build process).
    *   OS: Ubuntu 22.04 LTS atau 24.04 LTS.
2.  **Domain**: Sebuah domain yang sudah diarahkan (A Record) ke IP Address VPS Anda.
    *   Contoh: `dfresto.com` -> `123.456.78.90`
3.  **Akses SSH**: Kemampuan untuk login ke server via terminal.

---

## Langkah 1: Persiapan Server (Initial Server Setup)

Login ke server Anda sebagai root:
```bash
ssh root@your_server_ip
```

### 1.1 Update & Upgrade Sistem
```bash
apt update && apt upgrade -y
```

### 1.2 Buat User Baru (Opsional tapi Disarankan)
Jangan menjalankan aplikasi sebagai root demi keamanan.
```bash
adduser dfresto
# Ikuti instruksi membuat password
usermod -aG sudo dfresto
su - dfresto
```

### 1.3 Install Node.js (via NVM)
Kita akan menginstall Node.js versi LTS (v20+).
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts
nvm use --lts
node -v # Pastikan versi v20.x.x atau lebih baru
npm -v
```

> **Masalah Umum:** Jika muncul error `No such file or directory` atau `Command 'nvm' not found`:
> 1.  Cek apakah folder ada: `ls -ld ~/.nvm`
> 2.  **Jika tidak ada**, berarti install gagal. Jalankan ulang:
>     ```bash
>     curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
>     ```
> 3.  Jika sudah sukses install, baru jalankan:
>     ```bash
>     export NVM_DIR="$HOME/.nvm"
>     source "$HOME/.nvm/nvm.sh"
>     ```

### 1.4 Install Git & PM2
Git untuk clone repo, PM2 untuk menjalankan aplikasi di background.
```bash
sudo apt install git -y
npm install -g pm2
```

---

## Langkah 2: Setup Database (PostgreSQL)

Jika Anda tidak menggunakan Managed Database (seperti Supabase/Neon), install PostgreSQL di VPS yang sama.

### 2.1 Install PostgreSQL
```bash
sudo apt install postgresql postgresql-contrib -y
```

### 2.2 Buat User & Database
Masuk ke prompt Postgres:
```bash
sudo -u postgres psql
```

Jalankan perintah SQL berikut:
```sql
CREATE DATABASE dfresto_db;
CREATE USER dfresto_user WITH ENCRYPTED PASSWORD 'dFresto!';
GRANT ALL PRIVILEGES ON DATABASE dfresto_db TO dfresto_user;
\c dfresto_db
GRANT ALL ON SCHEMA public TO dfresto_user;
\q
```
*(Ganti `dFresto!` dengan password yang kuat)*

---

## Langkah 3: Setup Aplikasi (Next.js)

### 3.1 Upload Kode Aplikasi
Anda bisa memilih antara menggunakan Git (Disarankan) atau Upload Manual.

#### Opsi A: Clone Repository (Disarankan)
Pastikan kode Anda sudah ada di GitHub/GitLab.
```bash
cd ~
git clone https://github.com/username/dfresto.git
cd dfresto
```

#### Opsi B: Upload Manual (SCP / SFTP)
Jika tidak menggunakan Git, Anda bisa upload file project dari komputer lokal ke VPS.
1.  **Gunakan FileZilla / WinSCP**:
    *   Host: `your_server_ip`
    *   User: `dfresto`
    *   Password: (password user dfresto)
    *   Port: 22
2.  **Upload File**:
    *   Upload isi folder project lokal Anda ke `/home/dfresto/dfresto/`.
    *   **PENTING**: JANGAN upload folder berikut:
        *   `node_modules/`
        *   `.next/`
        *   `.git/`
        *   `.env` (Kita buat manual di server)
3.  **Verifikasi**:
    ```bash
    cd ~/dfresto
    ls -la # Pastikan file seperti package.json dan prisma/ ada
    ```

### 3.2 Install Dependencies
```bash
npm install
```

### 3.3 Setup Environment Variables
Buat file `.env` produksi.
```bash
cp .env.example .env
nano .env
```
Isi sesuai konfigurasi server:
```env
DATABASE_URL="postgresql://dfresto_user:password_rahasia_anda@localhost:5432/dfresto_db"
NEXTAUTH_URL="https://yourdomain.com"
NEXTAUTH_SECRET="buat_random_string_panjang_di_sini"
# Isi variabel lain sesuai kebutuhan
```
Simpan dengan `Ctrl+X`, lalu `Y`, lalu `Enter`.

### 3.4 Prisma Migration & Build
```bash
# Push schema ke database
npx prisma db push

# Generate client
npx prisma generate

# Seed database (jika perlu data awal)
npx prisma db seed

# Build aplikasi Next.js
npm run build
```
*Note: Jika build gagal karena memory (OOM), Anda mungkin perlu menambah Swap file pada VPS 1GB RAM.*

---

## Langkah 4: Menjalankan Aplikasi dengan PM2

Jalankan aplikasi Next.js menggunakan PM2 agar tetap hidup (restart otomatis jika crash/reboot).

```bash
pm2 start npm --name "dfresto" -- start
pm2 save
pm2 startup
```
*(Copy paste command yang muncul dari output `pm2 startup` jika diminta)*

---

## Langkah 5: Setup Nginx (Reverse Proxy)

Nginx bertugas menerima request dari internet (Port 80/443) dan meneruskannya ke aplikasi Next.js (Port 3000).

### 5.1 Install Nginx
```bash
sudo apt install nginx -y
```

### 5.2 Konfigurasi Server Block
Buat config baru untuk domain Anda.
```bash
sudo nano /etc/nginx/sites-available/dfresto
```

Isi dengan konfigurasi berikut:
```nginx
server {
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 5.3 Aktifkan Konfigurasi
```bash
sudo ln -s /etc/nginx/sites-available/dfresto /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default  # Hapus default jika tidak dipakai
sudo nginx -t # Cek error syntax
sudo systemctl restart nginx
```

---

## Langkah 6: Amankan dengan SSL (HTTPS)

Gunakan Certbot (Let's Encrypt) untuk SSL gratis.

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```
Ikuti instruksi di layar. Pilih opsi **Redirect** (2) agar semua traffic HTTP dipaksa ke HTTPS.

---

## Langkah Tambahan: Firewall (UFW)

Aktifkan firewall sederhana untuk keamanan.
```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## Selesai! 🚀
Aplikasi D'Fresto Anda sekarang sudah live di `https://yourdomain.com`.

### Tips Maintenance:
- **Lihat Logs Aplikasi:** `pm2 logs dfresto`
- **Update Aplikasi (Via Git):**
  ```bash
  cd ~/dfresto
  git pull
  npm install
  npx prisma db push
  npm run build
  pm2 restart dfresto
  ```
- **Update Aplikasi (Manual):**
  1. Upload file yang berubah via FileZilla/SCP (overwrite file lama).
  2. Jangan upload `node_modules` atau `.next`.
  3. Jalankan command di server:
     ```bash
     cd ~/dfresto
     npm install        # Jika package.json berubah
     npx prisma db push # Jika schema.prisma berubah
     npm run build      # Wajib jika ada perubahan code
     pm2 restart dfresto
     ```
